import { useEffect, useState } from "react";
import type { ReactNode } from "react";
import { CTAButton, Eyebrow, Reveal, Section } from "../components/ui";
import { BRAND } from "../brand";

/** Brand line icons — one weight, one colour, drawn to the salon's rose. */
function Icon({ name, className = "h-[22px] w-[22px]" }: { name: string; className?: string }) {
  const shapes: Record<string, ReactNode> = {
    clock: (
      <>
        <path d="M9.2 2.8h5.6" />
        <path d="M12 5.6v2" />
        <circle cx="12" cy="13.5" r="7.4" />
        <path d="M12 10.4v3.4l2.6 1.6" />
      </>
    ),
    talk: (
      <>
        <path d="M4.2 5.4h15.6v9.6H10l-4.4 3.4v-3.4H4.2z" />
        <path d="M8.2 10.2h7.6" />
      </>
    ),
    bottle: (
      <>
        <path d="M10 2.6h4v2.9h-4z" />
        <path d="M8.6 5.5h6.8v13.6a2.3 2.3 0 0 1-2.3 2.3h-2.2a2.3 2.3 0 0 1-2.3-2.3z" />
        <path d="M8.6 12.4h6.8" />
      </>
    ),
    diamond: (
      <>
        <path d="M12 3.4 20.6 10 12 20.6 3.4 10z" />
        <path d="M3.4 10h17.2" />
        <path d="M12 3.4 8.7 10l3.3 10.6L15.3 10z" />
      </>
    ),
    route: (
      <>
        <path d="M4.2 18.8c5.6 0 3.4-6.6 8.2-6.6 3 0 2.2-7.6 7.4-7.6" />
        <circle cx="4.2" cy="18.8" r="1.9" />
        <circle cx="19.8" cy="4.6" r="1.9" />
      </>
    ),
    target: (
      <>
        <circle cx="12" cy="12" r="8.4" />
        <circle cx="12" cy="12" r="4.4" />
        <circle cx="12" cy="12" r="1" fill="currentColor" stroke="none" />
      </>
    ),
    grid: (
      <>
        <rect x="3.4" y="5.2" width="17.2" height="15.4" rx="2.6" />
        <path d="M3.4 9.7h17.2" />
        <path d="M8 3.2v4M16 3.2v4" />
        <path d="M7.8 13.6h3.4M7.8 16.8h3.4M14.8 13.6h1.6M14.8 16.8h1.6" />
      </>
    ),
    flame: (
      <path d="M12.2 3.2c3.4 3.2 5.4 6 5.4 8.9a5.4 5.4 0 1 1-10.8 0c0-1.6.8-3 2-4.2.2 1.4 1 2.4 2.2 2.4 1.6 0 1.6-2.4-.8-4.7z" />
    ),
  };
  return (
    <svg
      viewBox="0 0 24 24"
      className={className}
      aria-hidden="true"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.6}
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {shapes[name]}
    </svg>
  );
}

const INCLUDED = [
  {
    icon: "clock",
    t: "5-Hour In-Salon Training Session",
    d: "Live, practical training focused on implementation — not theory.",
  },
  {
    icon: "talk",
    t: "Consultation Mastery",
    d: "Build confidence uncovering client needs and recommending solutions naturally.",
  },
  {
    icon: "bottle",
    t: "Retail Confidence Training",
    d: "Help your team educate and serve clients without feeling pushy or sales-focused.",
  },
  {
    icon: "diamond",
    t: "Treatment & High-Ticket Strategy",
    d: "Introduce premium treatments, upgrades and services with confidence.",
  },
  {
    icon: "route",
    t: "Client Journey Mapping",
    d: "A consistent, profitable experience from consultation to rebooking and aftercare.",
  },
  {
    icon: "target",
    t: "KPI & Target Clarity",
    d: "Practical benchmarks so every team member knows exactly what to aim for.",
  },
  {
    icon: "grid",
    t: "Systems & Daily Structure",
    d: "Simple systems — including the Daily Huddle — for consistency and accountability.",
  },
  {
    icon: "flame",
    t: "Team Engagement & Mindset",
    d: "Dismantle limiting beliefs around selling, pricing and communicating value.",
  },
];

const FRAMEWORKS = [
  {
    t: "Principles of C.A.R.E.",
    d: "Care, Attention, Respect and Excellence in every client interaction — the engine behind loyalty and referrals.",
  },
  {
    t: "The 10x10 Rule",
    d: "Consistency and repetition compounded into extraordinary salon performance.",
  },
  {
    t: "Communication Rating",
    d: "Audit your salon's communication channels and close the gaps with clients and team.",
  },
  {
    t: "Goal Setting for Results",
    d: "Clear, actionable goals with tracking so progress becomes measurable, not hopeful.",
  },
  {
    t: "Teamwork & Team Building",
    d: "A culture of collaboration that lifts morale, productivity and salon-wide results.",
  },
  {
    t: "Consultation Cheat Sheet",
    d: "Scripts, prompts and tools so every consultation is delivered at the same high standard.",
  },
];

export function Included() {
  return (
    <Section id="included">
      <Reveal>
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div className="max-w-2xl">
            <Eyebrow>What's included</Eyebrow>
            <h2 className="mt-5 font-display-light text-4xl leading-tight sm:text-5xl">
              Everything your team needs to sell with integrity.
            </h2>
          </div>
          <p className="max-w-sm text-sm leading-relaxed text-ink/60">
            Delivered in one focused day inside your salon, with workbooks,
            certificates and team gifts to lock the learning in.
          </p>
        </div>
      </Reveal>

      <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {INCLUDED.map((c, i) => (
          <Reveal key={c.t} delay={i * 60}>
            <div className="group flex h-full flex-col rounded-2xl border border-sand bg-white p-6 transition-all duration-300 hover:-translate-y-1.5 hover:shadow-[0_28px_60px_-34px_rgba(180,85,111,0.6)]">
              <div className="mb-5 grid h-12 w-12 place-items-center rounded-xl bg-blush/25 text-rose-deep transition-colors duration-300 group-hover:bg-blush/45">
                <Icon name={c.icon} />
              </div>
              <h3 className="font-display text-base font-medium leading-snug">
                {c.t}
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-ink/60">{c.d}</p>
            </div>
          </Reveal>
        ))}
      </div>

      <Reveal>
        <div className="mt-16 grid items-center gap-10 rounded-[2rem] border border-sand bg-sand/40 p-8 md:p-12 lg:grid-cols-[0.75fr_1.25fr]">
          <img
            src={BRAND.coursePoster}
            alt="The Accelerator Course by The Salon Dr."
            className="mx-auto w-full max-w-xs rounded-2xl shadow-[0_30px_60px_-35px_rgba(33,33,33,0.6)]"
            loading="lazy"
          />
          <div>
            <Eyebrow>The frameworks</Eyebrow>
            <h3 className="mt-4 font-display-light text-3xl sm:text-4xl">
              Tools your team will still be using in 12 months.
            </h3>
            <div className="mt-8 grid gap-x-10 gap-y-6 sm:grid-cols-2">
              {FRAMEWORKS.map((f, i) => (
                <div key={f.t} className="border-t border-rose/30 pt-4">
                  <div className="font-display text-xs font-semibold tracking-widest text-rose-deep">
                    0{i + 1}
                  </div>
                  <h4 className="mt-1 font-display text-lg font-medium">
                    {f.t}
                  </h4>
                  <p className="mt-1.5 text-sm leading-relaxed text-ink/60">
                    {f.d}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </Reveal>
    </Section>
  );
}

const AGENDA = [
  {
    time: "Hour 1",
    t: "Mindset & Money Beliefs",
    d: "Why your team resists selling — and how to replace that story with service-led confidence.",
  },
  {
    time: "Hour 2",
    t: "Consultation Mastery",
    d: "The question framework that uncovers real needs, plus objection handling that feels human.",
  },
  {
    time: "Hour 3",
    t: "Retail & Treatment Confidence",
    d: "Natural recommendation language, product storytelling and premium service upgrades.",
  },
  {
    time: "Hour 4",
    t: "Client Journey & C.A.R.E.",
    d: "Map the journey from booking to rebooking so nothing profitable gets skipped.",
  },
  {
    time: "Hour 5",
    t: "KPIs, Huddles & Commitments",
    d: "Set targets, install the Daily Huddle, and every team member signs an accountability card.",
  },
];

export function TrainingDay() {
  const [active, setActive] = useState(0);
  return (
    <Section id="day" className="bg-ink text-cream">
      <Reveal>
        <div className="max-w-2xl">
          <Eyebrow>The training day</Eyebrow>
          <h2 className="mt-5 font-display-light text-4xl leading-tight sm:text-5xl">
            Five hours that change how your salon{" "}
            <span className="font-semibold text-blush">
              talks, sells and serves.
            </span>
          </h2>
        </div>
      </Reveal>

      <div className="mt-12 grid gap-8 lg:grid-cols-[0.9fr_1.1fr]">
        <div className="space-y-2">
          {AGENDA.map((a, i) => (
            <button
              key={a.t}
              onMouseEnter={() => setActive(i)}
              onClick={() => setActive(i)}
              className={`flex w-full items-center gap-4 rounded-xl border px-5 py-4 text-left transition-all duration-300 ${
                active === i
                  ? "border-blush/70 bg-cream/10"
                  : "border-cream/10 hover:border-cream/30"
              }`}
            >
              <span
                className={`text-[10px] font-semibold uppercase tracking-[0.2em] ${
                  active === i ? "text-blush" : "text-cream/40"
                }`}
              >
                {a.time}
              </span>
              <span className="font-display text-base">{a.t}</span>
            </button>
          ))}
        </div>

        <div className="overflow-hidden rounded-[1.75rem] border border-cream/15 bg-cream/5">
          <img
            src={BRAND.workbooks}
            alt="Salon team with Accelerator Course workbooks"
            className="h-48 w-full object-cover"
            loading="lazy"
          />
          <div className="p-8 md:p-10">
            <div className="text-[11px] font-semibold uppercase tracking-[0.25em] text-blush">
              {AGENDA[active].time}
            </div>
            <h3 className="mt-3 font-display text-2xl">{AGENDA[active].t}</h3>
            <p className="mt-3 text-lg leading-relaxed text-cream/70">
              {AGENDA[active].d}
            </p>
            <div className="mt-7 grid gap-3 border-t border-cream/15 pt-6 text-sm text-cream/60 sm:grid-cols-2">
              <div>✓ Delivered in your salon, on your floor</div>
              <div>✓ Owners and team trained together</div>
              <div>✓ Workbooks, certificates & team gifts</div>
              <div>✓ Scripts ready to use next morning</div>
            </div>
          </div>
        </div>
      </div>
    </Section>
  );
}

export function Accountability() {
  return (
    <Section id="accountability">
      <div className="grid items-center gap-12 lg:grid-cols-2">
        <Reveal>
          <div className="relative">
            <div className="overflow-hidden rounded-[2rem] rounded-bl-[6rem] border-4 border-white shadow-[0_40px_80px_-45px_rgba(33,33,33,0.55)]">
              <img
                src={BRAND.accountability}
                alt="The Salon Dr. 30-day accountability session"
                className="h-[24rem] w-full object-cover sm:h-[30rem]"
                loading="lazy"
              />
            </div>
            <img
              src={BRAND.commitmentCard}
              alt="Personalised accountability commitment card"
              className="absolute -right-4 -bottom-8 w-36 rotate-3 rounded-xl border-4 border-white shadow-2xl sm:w-44"
              loading="lazy"
            />
            <div className="absolute -left-4 top-6 rounded-2xl bg-rose px-5 py-4 text-ink shadow-xl">
              <div className="font-display text-3xl font-semibold">30</div>
              <div className="text-[10px] font-semibold uppercase tracking-[0.18em]">
                Day accountability
              </div>
            </div>
          </div>
        </Reveal>

        <Reveal delay={120}>
          <div>
            <Eyebrow>The point of difference</Eyebrow>
            <h2 className="mt-5 font-display-light text-4xl leading-tight sm:text-5xl">
              Most training ends at 5pm. This one keeps going.
            </h2>
            <p className="mt-5 text-lg leading-relaxed text-ink/70">
              Thirty days after your training, you sit down with Sonia on Zoom
              and review your personalised accountability card — the goals your
              team set, the progress made, and the roadblocks in the way.
            </p>
            <ul className="mt-7 space-y-4">
              {[
                "Review every commitment made on training day",
                "Troubleshoot the habits that didn't stick",
                "Reset targets and celebrate the wins",
                "Lock in sustainable sales habits for good",
              ].map((x) => (
                <li key={x} className="flex gap-3 text-ink/75">
                  <span className="mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded-full bg-rose text-xs text-white">
                    ✓
                  </span>
                  <span>{x}</span>
                </li>
              ))}
            </ul>
            <div className="mt-8 rounded-2xl border-l-4 border-rose bg-sand/50 p-6 font-display text-lg leading-relaxed">
              “True growth comes from continuous improvement and
              accountability.”
              <span className="mt-2 block text-sm text-ink/50">
                — Sonia Tomas, The Salon Dr.
              </span>
            </div>
          </div>
        </Reveal>
      </div>
    </Section>
  );
}

const AUDIENCE = [
  {
    t: "Salon Owners & Managers",
    d: "Who want to lead teams more effectively, increase profitability and elevate the client experience.",
  },
  {
    t: "Aspiring Salon Leaders",
    d: "Developing the skills to step into managerial roles and drive salon success.",
  },
  {
    t: "Experienced Hairdressers",
    d: "Ready to grow beyond technical skill into business growth, client satisfaction and collaboration.",
  },
  {
    t: "Whole Salon Teams",
    d: "Committed to common goals, better communication and a thriving salon environment.",
  },
];

export function WhoFor() {
  return (
    <Section className="bg-sand/40">
      <Reveal>
        <div className="mx-auto max-w-2xl text-center">
          <Eyebrow>Who it's for</Eyebrow>
          <h2 className="mt-5 font-display-light text-4xl leading-tight sm:text-5xl">
            Built for owners and staff — because the gap lives between them.
          </h2>
        </div>
      </Reveal>
      <div className="mt-12 grid gap-5 md:grid-cols-2 lg:grid-cols-4">
        {AUDIENCE.map((a, i) => (
          <Reveal key={a.t} delay={i * 80}>
            <div className="h-full rounded-2xl bg-white p-7 shadow-[0_20px_50px_-40px_rgba(33,33,33,0.7)]">
              <div className="font-display text-4xl font-semibold text-blush">
                0{i + 1}
              </div>
              <h3 className="mt-3 font-display text-lg font-medium leading-snug">
                {a.t}
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-ink/60">{a.d}</p>
            </div>
          </Reveal>
        ))}
      </div>
      <Reveal>
        <div className="mt-12 text-center">
          <CTAButton className="px-8 py-4 text-base">
            Book Your Salon's Training Day
          </CTAButton>
        </div>
      </Reveal>
    </Section>
  );
}

const TESTIMONIALS = [
  {
    quote:
      "Sonia, I literally can't. I've just been reflecting on our year — this time last year we did $21k and $1k of retail. Comparatively this year was $34k and over $4k in retail. Our stylist went from $800 a week to over $4k a week because she's now not scared of what to offer.",
    name: "Salon owner",
    role: "One year after the Accelerator Course",
    stat: "$1k → $4k+ retail a year",
  },
  {
    quote:
      "Hey beautiful, I just needed to let you know how great we went after having you in the salon — our retail went up by 267%. Everyone can't believe how different they felt with consultations. Loved every second of it 🙌 thank you a million!!!",
    name: "Salon owner",
    role: "In-salon training day",
    stat: "+267% retail",
  },
  {
    quote:
      "I almost didn't do it. We've done various courses and coaching over time and wasn't that convinced. But after we did, the team was recharged — they really loved Sonia's energy and laid-back, straight-to-the-point approach. We saw our retail go up by 80% in the first week.",
    name: "Salon owner",
    role: "In-salon training day",
    stat: "+80% retail in week one",
  },
  {
    quote:
      "After being so motivated from today's call and the retail tips, I made an extra $431 today. Every client bought retail and 2 treatment upgrades — also note I was on my own today.",
    name: "Rachael May",
    role: "Stylist",
    stat: "+$431 in one shift",
  },
  {
    quote:
      "11 retail products sold today, $418.65. This week — 42 retail products, $1,734. We almost made our total for the week and made $4,945, and Sarah almost made her total, she made $1,136.",
    name: "Salon team",
    role: "Week after the Accelerator Course",
    stat: "42 products · $1,734",
  },
  {
    quote:
      "Today has been the best day at work I've had since coming back. All the girls are so motivated and focused. We are absolutely smashing the retail sales and all clients have walked out with products 😭❤️🙌",
    name: "Stylist",
    role: "The day after the training",
    stat: "Every client left with product",
  },
  {
    quote:
      "On Monday, our team had the absolute pleasure of an in-salon training day diving deep into retail, targets, and truly caring for our clients. Sometimes you don't realise what your business — or your team — is missing until you meet someone like Sonia. Thank you for taking the time to travel all the way to Gunnedah.",
    name: "Soul Hair Studio",
    role: "Gunnedah, NSW",
    stat: "In-salon · regional NSW",
  },
  {
    quote:
      "I'm blown away! We have all hit our target of $2,346 in retail in one week. The team are just so excited and loving the feedback clients are giving us! You're amazing! Thank you!",
    name: "Shenade",
    role: "Hair Shenanigans",
    stat: "$2,346 retail in one week",
  },
];

export function Testimonial() {
  const [i, setI] = useState(0);
  const [paused, setPaused] = useState(false);
  const count = TESTIMONIALS.length;

  useEffect(() => {
    if (paused) return;
    if (
      typeof window !== "undefined" &&
      window.matchMedia("(prefers-reduced-motion: reduce)").matches
    ) {
      return;
    }
    const id = window.setInterval(
      () => setI((v) => (v + 1) % count),
      7000,
    );
    return () => window.clearInterval(id);
  }, [paused, count, i]);

  const go = (n: number) => setI((n + count) % count);
  const t = TESTIMONIALS[i];

  return (
    <div
      className="bg-ink text-cream"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
      onFocusCapture={() => setPaused(true)}
      onBlurCapture={() => setPaused(false)}
    >
    <Section>
      <div className="grid gap-10 lg:grid-cols-[1.35fr_0.65fr]">
        <div className="min-w-0">
          <div className="flex items-center justify-between gap-6">
            <Eyebrow>What salons are saying</Eyebrow>
            <span className="num text-xs text-cream/40">
              {String(i + 1).padStart(2, "0")} / {String(count).padStart(2, "0")}
            </span>
          </div>

          <div className="mt-8 grid">
            {TESTIMONIALS.map((item, idx) => (
              <figure
                key={item.name + idx}
                aria-hidden={idx !== i}
                className={`col-start-1 row-start-1 transition-all duration-700 ease-out ${
                  idx === i
                    ? "translate-y-0 opacity-100"
                    : "pointer-events-none translate-y-3 opacity-0"
                }`}
              >
                <span
                  aria-hidden
                  className="block font-display text-6xl leading-none text-blush"
                >
                  &ldquo;
                </span>
                <blockquote className="mt-2 max-w-3xl font-display-light text-2xl leading-snug sm:text-3xl lg:text-4xl">
                  {item.quote}
                </blockquote>
              </figure>
            ))}
          </div>

          <div className="mt-8 flex flex-wrap items-center gap-x-6 gap-y-4">
            <span className="inline-flex items-center gap-3">
              <span className="h-px w-10 bg-blush" />
              <span className="font-display font-medium">{t.name}</span>
            </span>
            <span className="text-sm text-cream/50">{t.role}</span>
            <span className="rounded-full border border-blush/40 px-3 py-1 text-xs font-semibold tracking-wide text-blush">
              {t.stat}
            </span>
          </div>

          {/* progress + controls */}
          <div className="mt-10 flex flex-wrap items-center gap-5">
            <button
              onClick={() => go(i - 1)}
              aria-label="Previous testimonial"
              className="grid h-10 w-10 place-items-center rounded-full border border-cream/20 transition hover:border-blush hover:text-blush"
            >
              <span aria-hidden>‹</span>
            </button>
            <button
              onClick={() => go(i + 1)}
              aria-label="Next testimonial"
              className="grid h-10 w-10 place-items-center rounded-full border border-cream/20 transition hover:border-blush hover:text-blush"
            >
              <span aria-hidden>›</span>
            </button>

            <div className="flex flex-1 items-center gap-2" role="tablist" aria-label="Testimonials">
              {TESTIMONIALS.map((item, idx) => (
                <button
                  key={item.name + idx}
                  onClick={() => setI(idx)}
                  aria-label={`Show testimonial ${idx + 1}`}
                  aria-selected={idx === i}
                  role="tab"
                  className={`h-1.5 rounded-full transition-all duration-300 ${
                    idx === i ? "w-10 bg-blush" : "w-4 bg-cream/25 hover:bg-cream/50"
                  }`}
                />
              ))}
            </div>
          </div>

          <div className="mt-5 h-0.5 w-full overflow-hidden rounded-full bg-cream/10">
            <div
              key={`${i}-${paused}`}
              className={`h-full bg-blush/70 ${paused ? "" : "progress-fill"}`}
              style={paused ? { width: "0%" } : undefined}
            />
          </div>
        </div>

        <div className="hidden lg:block">
          <img
            src={BRAND.teamSession}
            alt="Salon team at an Accelerator Course training session"
            className="h-80 w-full rounded-[2rem] object-cover lg:h-[26rem]"
            loading="lazy"
          />
        </div>
      </div>
    </Section>
    </div>
  );
}
