import { useState } from "react";
import { CTAButton, Eyebrow, Reveal, Section } from "../components/ui";
import { BRAND } from "../brand";

type Mode = "salon" | "online";

const MODES: Record<
  Mode,
  {
    label: string;
    tag: string;
    headline: string;
    blurb: string;
    img: string;
    alt: string;
    best: string;
    points: string[];
    format: [string, string][];
  }
> = {
  salon: {
    label: "In-Salon",
    tag: "Most popular",
    headline: "Sonia comes to you.",
    blurb:
      "A full 5-hour training day delivered on your salon floor, using your retail shelf, your service menu and your real client scenarios. The energy of the whole team in one room is hard to beat.",
    img: BRAND.trainingRoom,
    alt: "Sonia Tomas delivering in-salon training to a hair team",
    best: "Best for teams of 4+ who want maximum momentum and culture change.",
    points: [
      "5-hour live training on your salon floor",
      "Sonia works your actual retail shelf and menu",
      "Role-play real consultations with your team",
      "Printed workbooks, certificates & team gifts on the day",
      "Signed accountability cards before anyone leaves",
      "Highest engagement — zero screen distraction",
    ],
    format: [
      ["Duration", "5 hours, one day"],
      ["Location", "Your salon, Australia wide"],
      ["Group", "Your whole team together"],
      ["Follow-up", "30-day Zoom accountability"],
    ],
  },
  online: {
    label: "Online",
    tag: "Flexible",
    headline: "Same framework. Delivered live over Zoom.",
    blurb:
      "Perfect for regional salons, smaller teams or owners who'd rather split the training across shorter sessions. Still live, still interactive, still led personally by Sonia — never a pre-recorded course.",
    img: BRAND.accountability,
    alt: "Sonia Tomas delivering an online coaching session over Zoom",
    best: "Best for regional salons, smaller teams or split-shift rosters.",
    points: [
      "Live, interactive Zoom training with Sonia",
      "Run in one block or split across sessions",
      "Digital workbooks & consultation cheat sheet sent ahead",
      "No travel costs, no closing the salon for a full day",
      "Session notes so absent team members can catch up",
      "Ideal for regional and multi-location salons",
    ],
    format: [
      ["Duration", "5 hours, or 2 × 2.5 hr sessions"],
      ["Location", "Live on Zoom, anywhere"],
      ["Group", "Team joins together or individually"],
      ["Follow-up", "30-day Zoom accountability"],
    ],
  },
};

const SHARED = [
  "Discovery session before training",
  "Consultation Mastery framework",
  "Retail & treatment confidence",
  "C.A.R.E. + 10x10 Rule",
  "KPIs, targets & Daily Huddle",
  "30-day accountability session",
];

export function Delivery() {
  const [mode, setMode] = useState<Mode>("salon");
  const m = MODES[mode];

  return (
    <Section id="delivery" className="bg-sand/40">
      <Reveal>
        <div className="mx-auto max-w-2xl text-center">
          <Eyebrow>Two ways to run it</Eyebrow>
          <h2 className="mt-5 font-display-light text-4xl leading-tight sm:text-5xl">
            In your salon, or live online.
          </h2>
          <p className="mt-5 text-ink/65">
            Same proven framework, same accountability. Choose the delivery that
            suits your team, your roster and your location.
          </p>
        </div>
      </Reveal>

      <Reveal delay={80}>
        <div className="mt-10 flex justify-center">
          <div className="inline-flex rounded-full border border-rose/30 bg-white p-1.5 shadow-sm">
            {(Object.keys(MODES) as Mode[]).map((k) => (
              <button
                key={k}
                onClick={() => setMode(k)}
                className={`rounded-full px-7 py-3 text-sm font-semibold transition-all duration-300 ${
                  mode === k
                    ? "bg-ink text-cream shadow"
                    : "text-ink/55 hover:text-ink"
                }`}
              >
                {MODES[k].label}
              </button>
            ))}
          </div>
        </div>
      </Reveal>

      <Reveal delay={120}>
        <div className="mt-10 overflow-hidden rounded-[2rem] border border-sand bg-white shadow-[0_30px_70px_-45px_rgba(33,33,33,0.55)]">
          <div className="grid lg:grid-cols-[0.85fr_1.15fr]">
            <div className="relative">
              <img
                key={m.img}
                src={m.img}
                alt={m.alt}
                className="h-64 w-full object-cover lg:h-full"
                loading="lazy"
              />
              <span className="absolute left-5 top-5 rounded-full bg-rose px-4 py-1.5 text-[10px] font-semibold uppercase tracking-[0.18em] text-ink shadow">
                {m.tag}
              </span>
            </div>

            <div className="p-8 md:p-11">
              <h3 className="font-display-light text-3xl leading-snug sm:text-4xl">
                {m.headline}
              </h3>
              <p className="mt-4 text-ink/70">{m.blurb}</p>

              <ul className="mt-7 grid gap-x-8 gap-y-3 sm:grid-cols-2">
                {m.points.map((p) => (
                  <li key={p} className="flex gap-3 text-sm text-ink/75">
                    <span className="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full bg-rose text-[10px] text-white">
                      ✓
                    </span>
                    <span>{p}</span>
                  </li>
                ))}
              </ul>

              <div className="mt-8 grid gap-px overflow-hidden rounded-2xl bg-sand sm:grid-cols-2">
                {m.format.map(([k, v]) => (
                  <div key={k} className="bg-white p-4">
                    <div className="text-[10px] font-semibold uppercase tracking-[0.18em] text-ink/45">
                      {k}
                    </div>
                    <div className="mt-1 font-display text-sm font-medium">
                      {v}
                    </div>
                  </div>
                ))}
              </div>

              <p className="mt-6 rounded-xl border-l-4 border-rose bg-sand/50 px-5 py-3 text-sm text-ink/75">
                {m.best}
              </p>

              <div className="mt-7 flex flex-wrap gap-3">
                <CTAButton>Enquire About {m.label} Training</CTAButton>
                <CTAButton href="#book" variant="ghost">
                  Book a Discovery Call
                </CTAButton>
              </div>
            </div>
          </div>
        </div>
      </Reveal>

      <Reveal delay={160}>
        <div className="mt-10 rounded-[2rem] border border-rose/30 bg-white/70 p-8 text-center">
          <h4 className="font-display text-lg font-medium">
            Included in both formats
          </h4>
          <div className="mt-5 flex flex-wrap justify-center gap-2.5">
            {SHARED.map((s) => (
              <span
                key={s}
                className="rounded-full border border-sand bg-white px-4 py-2 text-xs font-medium text-ink/70"
              >
                ✓ {s}
              </span>
            ))}
          </div>
          <p className="mt-6 text-sm text-ink/55">
            Not sure which fits your salon? Sonia will recommend the right
            format on your free 15-minute discovery call.
          </p>
        </div>
      </Reveal>
    </Section>
  );
}
