import { useEffect, useState, type FormEvent } from "react";
import { CTAButton, Eyebrow, Reveal } from "../components/ui";
import { BRAND } from "../brand";
import { openBooking } from "../booking";
import { Logo } from "./Top";

const FIELDS = [
  { name: "name", label: "Your name", type: "text", ph: "Jane Smith" },
  { name: "salon", label: "Salon name", type: "text", ph: "Luxe Hair Co." },
  { name: "email", label: "Email", type: "email", ph: "you@salon.com.au" },
  { name: "phone", label: "Phone", type: "tel", ph: "04__ ___ ___" },
];

export function Apply() {
  const [sent, setSent] = useState(false);
  const [delivery, setDelivery] = useState("In-salon");

  const submit = (e: FormEvent) => {
    e.preventDefault();
    setSent(true);
  };

  return (
    <section id="apply" className="relative overflow-hidden bg-ink px-5 py-24 text-cream md:py-32">
      <div className="pointer-events-none absolute -left-32 top-0 h-96 w-96 rounded-full bg-blush/30 blur-3xl" />
      <div className="pointer-events-none absolute -right-32 bottom-0 h-96 w-96 rounded-full bg-gold/15 blur-3xl" />

      <div className="relative mx-auto grid w-full max-w-6xl items-start gap-14 lg:grid-cols-[1fr_1fr]">
        <Reveal>
          <div>
            <Eyebrow>Next step</Eyebrow>
            <h2 className="mt-5 font-display-light text-4xl leading-[1.08] sm:text-6xl">
              Ready to stop leaving money on the shelf?
            </h2>
            <p className="mt-6 max-w-lg text-lg text-cream/70">
              Tell us a little about your salon and Sonia will personally come
              back to you with available dates and a tailored proposal for your
              team.
            </p>

            <div className="mt-10 space-y-4">
              {[
                "Delivered in your salon or live online — your choice",
                "5-hour training for your whole team",
                "Workbooks, certificates & team gifts included",
                "30-day accountability session with Sonia",
                "No obligation — just a conversation",
              ].map((x) => (
                <div key={x} className="flex items-center gap-3 text-cream/80">
                  <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-rose text-xs text-ink">
                    ✓
                  </span>
                  {x}
                </div>
              ))}
            </div>

            <div className="mt-9 rounded-2xl border border-blush/40 bg-cream/10 p-6">
              <div className="font-display text-lg">
                Prefer to talk it through first?
              </div>
              <p className="mt-1.5 text-sm text-cream/65">
                Grab a free 15-minute discovery call and pick a time that suits
                you from Sonia's live calendar.
              </p>
              <CTAButton href="#book" variant="light" className="mt-4">
                See Available Times
              </CTAButton>
            </div>
          </div>
        </Reveal>

        <Reveal delay={120}>
          <div className="rounded-[2rem] bg-cream p-7 text-ink shadow-[0_40px_90px_-40px_rgba(0,0,0,0.9)] md:p-10">
            {sent ? (
              <div className="py-12 text-center">
                <div className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-rose text-2xl text-ink">
                  ✓
                </div>
                <h3 className="mt-6 font-display text-3xl">
                  Enquiry received.
                </h3>
                <p className="mt-3 text-ink/65">
                  Beautiful. Sonia will be in touch within one business day with
                  availability for your salon.
                </p>
              </div>
            ) : (
              <form onSubmit={submit} className="space-y-5">
                <div className="flex items-start gap-4">
                  <img
                    src={BRAND.logo}
                    alt="The Salon Dr."
                    className="h-12 w-12 shrink-0 object-contain"
                  />
                  <div>
                  <h3 className="font-display text-2xl leading-tight">
                    Enquire about your salon's date
                  </h3>
                  <p className="mt-1 text-sm text-ink/55">
                    Takes under 60 seconds.
                  </p>
                  </div>
                </div>

                <div className="grid gap-5 sm:grid-cols-2">
                  {FIELDS.map((f) => (
                    <label key={f.name} className="block">
                      <span className="text-[11px] font-semibold uppercase tracking-[0.15em] text-ink/50">
                        {f.label}
                      </span>
                      <input
                        required
                        type={f.type}
                        placeholder={f.ph}
                        className="mt-2 w-full rounded-xl border border-sand bg-white px-4 py-3 text-sm outline-none transition focus:border-rose focus:ring-2 focus:ring-blush/40"
                      />
                    </label>
                  ))}
                </div>

                <div>
                  <span className="text-[11px] font-semibold uppercase tracking-[0.15em] text-ink/50">
                    Preferred delivery
                  </span>
                  <div className="mt-2 grid grid-cols-3 gap-2">
                    {["In-salon", "Online", "Not sure yet"].map((o) => (
                      <button
                        key={o}
                        type="button"
                        onClick={() => setDelivery(o)}
                        className={`rounded-xl border px-2 py-3 text-xs font-semibold transition ${
                          delivery === o
                            ? "border-rose bg-rose text-ink"
                            : "border-sand bg-white text-ink/60 hover:border-rose/50"
                        }`}
                      >
                        {o}
                      </button>
                    ))}
                  </div>
                </div>

                <label className="block">
                  <span className="text-[11px] font-semibold uppercase tracking-[0.15em] text-ink/50">
                    Team size
                  </span>
                  <select
                    className="mt-2 w-full rounded-xl border border-sand bg-white px-4 py-3 text-sm outline-none focus:border-rose focus:ring-2 focus:ring-blush/40"
                    defaultValue=""
                  >
                    <option value="" disabled>
                      Select…
                    </option>
                    <option>1–4 team members</option>
                    <option>5–9 team members</option>
                    <option>10–15 team members</option>
                    <option>16+ team members</option>
                  </select>
                </label>

                <label className="block">
                  <span className="text-[11px] font-semibold uppercase tracking-[0.15em] text-ink/50">
                    What's your biggest challenge right now?
                  </span>
                  <textarea
                    rows={3}
                    placeholder="Retail isn't moving, consultations are inconsistent…"
                    className="mt-2 w-full resize-none rounded-xl border border-sand bg-white px-4 py-3 text-sm outline-none transition focus:border-rose focus:ring-2 focus:ring-blush/40"
                  />
                </label>

                <button
                  type="submit"
                  className="w-full rounded-full bg-ink px-7 py-4 text-sm font-semibold text-cream transition hover:bg-rose hover:text-ink active:scale-[0.99]"
                >
                  Send My Enquiry →
                </button>
                <p className="text-center text-xs text-ink/45">
                  Your details stay private. No spam, ever.
                </p>
              </form>
            )}
          </div>
        </Reveal>
      </div>
    </section>
  );
}

export function Footer() {
  return (
    <footer className="bg-ink px-5 pb-10 text-cream/60">
      <div className="mx-auto flex w-full max-w-6xl flex-col items-center justify-between gap-4 border-t border-cream/10 pt-8 text-sm sm:flex-row">
        <Logo dark />
        <div className="flex gap-6">
          <a href="#included" className="hover:text-blush">
            Program
          </a>
          <a href="#faq" className="hover:text-blush">
            FAQ
          </a>
          <a href="#apply" className="hover:text-blush">
            Enquire
          </a>
          <button onClick={openBooking} className="hover:text-blush">
            Book a Call
          </button>
        </div>
        <div className="text-xs text-cream/35">
          © {new Date().getFullYear()} The Salon Dr. All rights reserved.
        </div>
      </div>
    </footer>
  );
}

export function StickyCTA() {
  const [show, setShow] = useState(false);
  useEffect(() => {
    const onScroll = () => setShow(window.scrollY > 700);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  return (
    <div
      className={`fixed inset-x-0 bottom-0 z-40 border-t border-ink/10 bg-cream/95 p-3 backdrop-blur transition-transform duration-300 sm:hidden ${
        show ? "translate-y-0" : "translate-y-full"
      }`}
    >
      <div className="flex gap-2">
        <button
          onClick={openBooking}
          className="flex-1 rounded-full border border-ink/25 py-3.5 text-center text-sm font-semibold text-ink"
        >
          Book a Call
        </button>
        <a
          href="#apply"
          className="flex-[1.3] rounded-full bg-ink py-3.5 text-center text-sm font-semibold text-cream"
        >
          Enquire Now →
        </a>
      </div>
    </div>
  );
}
