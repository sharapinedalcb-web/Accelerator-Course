const W = "https://static.wixstatic.com/media/";

const fit = (id: string, w: number, h: number, q = 85) =>
  `${W}${id}/v1/fill/w_${w},h_${h},al_c,q_${q},usm_0.66_1.00_0.01/file.${
    id.endsWith(".png") || id.includes("~mv2.png") ? "png" : "jpg"
  }`;

/** Official The Salon Dr. brand assets, pulled from thesalondr.com.au */
export const BRAND = {
  logo: fit("f5b531_cefc9ca54cd34d6487b600218b43e997~mv2.png", 300, 282),
  heartbeat: fit("f5b531_bd47b5df9bf4406fae0ce2a5ec532f01~mv2.png", 1000, 170),

  /** Sonia Tomas, founder portrait */
  soniaPortrait: fit("f5b531_f8b74ee331a0478ea5019cf99892ec69~mv2.jpg", 900, 980, 80),
  /** Sonia training in salon (tall) */
  soniaTraining: fit("f5b531_d189f572b1bc44f58fac69ec63cf91d4~mv2.jpg", 760, 1100, 80),
  /** Sonia, hair educator */
  soniaEducator: fit("f5b531_d2398983d8844ae6943203e54ea2f814~mv2.jpg", 760, 1040, 80),


  /** Accelerator Course official course graphic */
  coursePoster: fit("f5b531_8d68a2e7e1bf4f1b87b719ce7ab89198~mv2.png", 758, 1074),
  /** Accountability / commitment card graphic */
  commitmentCard: fit("f5b531_4afefa4dfb534129a78cdfce98d306e6~mv2.png", 700, 996),

  /** In-salon training day photography */
  trainingRoom: fit("f5b531_4673a1c10b134d5fb90fafa548a3757b~mv2.jpg", 1200, 800, 80),
  workbooks: fit("6bcf13_8ba77218036b4f69b28158f38a343aee~mv2.jpg", 1100, 740, 80),
  teamSession: fit("f5b531_31741032c5554cc189b7bad1260be062~mv2.jpg", 1100, 740, 80),
  accountability: fit("6bcf13_182d3d790f814d35acf7177d7a76c412~mv2.jpeg", 700, 902, 80),
};
